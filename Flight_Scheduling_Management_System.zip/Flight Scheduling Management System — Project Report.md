# Flight Scheduling Management System — Project Report

## Abstract

The Flight Scheduling Management System is a Java-based desktop application that supports core airline reservation operations through a graphical interface. It provides authentication, passenger registration, flight browsing, ticket booking, journey lookup, boarding-pass viewing, and ticket cancellation. The application demonstrates event-driven programming, JDBC database connectivity, relational data management, and modular Swing screen design.

## Problem statement

Manual airline record handling makes it difficult to maintain consistent passenger, flight, and reservation information. The proposed system centralizes these records in a database and exposes common operational tasks through a single desktop application. This reduces repeated data entry and gives an operator a predictable workflow for managing a journey from passenger registration to cancellation.

## Objectives

The project aims to provide a simple authenticated interface for airline operations, persist records in a relational database, support the complete reservation lifecycle, and demonstrate a maintainable Java desktop application structure suitable for academic evaluation.

## Functional modules

| Module | Responsibility |
|---|---|
| Authentication | Verifies operator credentials before access to the main menu. |
| Passenger management | Captures passenger name, nationality, phone, address, identity number, and gender. |
| Flight management | Displays available flights and finds a route-specific flight. |
| Booking | Fetches passenger information, selects a route, and creates a PNR and ticket record. |
| Journey details | Retrieves a reservation by PNR. |
| Boarding pass | Presents reservation information as a boarding-pass view. |
| Cancellation | Retrieves a reservation, records cancellation details, and removes the active reservation. |

## System design

The application follows a desktop three-layer direction. Swing screens form the presentation layer. The event handlers and JDBC queries form the application/data-access layer. MySQL provides persistence. `Conn` centralizes connection creation, while `ResultSetTableModel` adapts JDBC results for tabular Swing views.

```text
Operator
   |
   v
Swing screens --> JDBC connection helper --> MySQL database
       |
       +--> Passenger, Flight, Reservation, Cancellation records
```

## Database design

The database contains `login`, `passenger`, `flight`, `reservation`, and `cancel` tables. A passenger may have reservations, and each reservation references the passenger identity value. A reservation receives a unique PNR and ticket identifier. The complete executable schema and seed data are provided in `database/schema.sql`.

## Testing and verification

The project was verified by compiling it with Apache Ant after replacing the original machine-specific library paths. The rebuilt JAR includes the corrected `FlightSchedulingManagementSystem` entry point and the application starts successfully in a virtual display environment. Database-dependent workflows require MySQL to be running with the supplied schema loaded.

## Security and quality improvements

The submission version removes the hard-coded database password from source code and reads connection settings from environment variables. Login verification uses a prepared statement rather than concatenating user input into SQL. The unavailable third-party result-set table adapter was replaced with a local implementation, reducing setup friction and making the build reproducible.

## Conclusion

The project demonstrates a complete airline reservation workflow in a Java Swing environment. Its modular screens and relational schema provide a clear foundation for an academic submission. A production-grade extension would add password hashing, stronger authorization, service-layer separation, typed dates, database transactions, automated tests, and modern layout management.

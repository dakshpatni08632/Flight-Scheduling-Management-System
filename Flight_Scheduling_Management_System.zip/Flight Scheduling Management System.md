# Flight Scheduling Management System

A Java Swing desktop application for managing airline passengers, flights, reservations, journey details, boarding passes, and ticket cancellations. This version has been prepared for academic project submission with a reproducible build, portable dependencies, database setup script, and a documented application entry point.

## Project overview

The application models a small airline reservation workflow. An operator signs in, registers passenger information, reviews available flights, books a journey, retrieves reservation details, generates a boarding pass, and cancels a reservation when required.

The project uses a modular desktop architecture. Swing and AWT provide the user interface, JDBC provides database access, MySQL stores the operational records, and Apache Ant builds the NetBeans project. The main class is `flightschedulingmanagementsystem.FlightSchedulingManagementSystem`.

## Features

- Username and password authentication
- Passenger registration with identity and contact details
- Flight listing and route-based flight lookup
- Reservation creation with PNR and ticket identifiers
- Journey-detail lookup by PNR
- Boarding-pass display
- Reservation cancellation with cancellation record
- Reusable JDBC result-set table model
- Environment-based database configuration

## Technology stack

| Layer | Technology |
|---|---|
| User interface | Java Swing and AWT |
| Language/runtime | Java 17 or newer |
| Database | MySQL 8 or compatible server |
| Connectivity | JDBC with MySQL Connector/J |
| Build | Apache Ant / NetBeans project |
| Calendar input | JCalendar |

## Project structure

```text
FlightSchedulingManagementSystem/
├── database/schema.sql                         Database and seed data
├── lib/                                        Portable third-party JARs
├── src/flightschedulingmanagementsystem/
│   ├── FlightSchedulingManagementSystem.java            Application entry point
│   ├── Login.java                              Authentication screen
│   ├── Home.java                               Main navigation screen
│   ├── AddCustomer.java                        Passenger registration
│   ├── FlightInfo.java                         Flight listing
│   ├── BookFlight.java                         Reservation workflow
│   ├── JourneyDetails.java                     PNR lookup
│   ├── BoardingPass.java                       Boarding-pass screen
│   ├── Cancel.java                             Cancellation workflow
│   ├── Conn.java                               JDBC connection helper
│   └── ResultSetTableModel.java                JDBC-to-Swing table adapter
├── nbproject/                                  NetBeans build configuration
├── build.xml                                   Apache Ant build file
└── dist/                                       Generated JAR output
```

## Requirements

Install Java Development Kit 17 or newer, Apache Ant, and MySQL 8. The required Java libraries are included in `lib/`, so the project no longer depends on absolute paths from the original developer’s computer.

## Database setup

1. Start MySQL.
2. Execute `database/schema.sql` in MySQL Workbench or the MySQL client.
3. The script creates the `flightschedulingmanagementsystem` database, tables, sample flights, and the demo login.
4. The default demo credentials are `admin` and `admin123`.

For a non-default database configuration, set these environment variables before starting the application:

```bash
export FLIGHT_DB_URL='jdbc:mysql://localhost:3306/flightschedulingmanagementsystem?serverTimezone=UTC'
export FLIGHT_DB_USER='root'
export FLIGHT_DB_PASSWORD='your_mysql_password'
```

The application uses these values instead of storing a machine-specific password in source code.

## Build and run

From the project root:

```bash
ant clean jar
java -cp "lib/*:dist/FlightSchedulingManagementSystem.jar" flightschedulingmanagementsystem.FlightSchedulingManagementSystem
```

On Windows, use the equivalent semicolon-separated classpath:

```bat
java -cp "lib/*;dist/FlightSchedulingManagementSystem.jar" flightschedulingmanagementsystem.FlightSchedulingManagementSystem
```

The project can also be opened directly in NetBeans as an existing Ant project. Run the `FlightSchedulingManagementSystem` class rather than opening an individual screen.

## Academic submission notes

This is an educational desktop application. The current authentication table is intentionally simple for demonstration and should not be used as-is for a production system. A production version should hash passwords, add role-based permissions, use typed date columns, add audit logging, and move all database operations into a service layer.

The refactoring included in this submission fixes the missing application launcher, removes the unavailable `rs2xml` dependency, replaces absolute Windows library paths with portable project-relative paths, adds a database schema, makes connection settings configurable, and uses a prepared statement for login verification.

## Limitations and future scope

The interface remains a classic Swing desktop UI and uses some legacy absolute-position layout code inherited from the original project. Future work could introduce layout managers, stronger validation, password hashing, typed date fields, transaction handling for booking and cancellation, role-based access, automated tests, and a REST/web client.

## License

This project is provided for educational purposes.
